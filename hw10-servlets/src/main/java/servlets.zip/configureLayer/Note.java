package configureLayer;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;


@Getter
@Setter
public class Note {
    public String title;
    public String content;

}
